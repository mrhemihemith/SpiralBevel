from flask import Flask, render_template, request
import math

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def calculate_loads():
    if request.method == 'POST':
        # Retrieve inputs from the form
        HP = float(request.form['HP'])
        N = float(request.form['N'])
        NP = float(request.form['NP'])
        NG = float(request.form['NG'])
        M = float(request.form['M'])
        alpha = (float(request.form['alpha']))  # Convert to radians
        gamma = (float(request.form['spiral_angle']))  # Convert to radians
        rotation = request.form['rotation']
        a = float(request.form['a'])
        b = float(request.form['b'])
        c = float(request.form['c'])
        d = float(request.form['d'])

        helix = (float(request.form['helix']))

        a1 = float(request.form['a1'])
        b1 = float(request.form['b1'])
        c1 = float(request.form['c1'])
        d1 = float(request.form['d1'])

        # Calculating Q and P

        Q_kg_m = (HP*4500)/(2*math.pi*N)
        
        pinion_dia = (M*NP)/(math.cos(gamma*math.pi/180))
        
        P_kg = (Q_kg_m*2000)/(pinion_dia)

        beta = math.degrees(math.atan(NP/NG))

        Tp = P_kg * ((math.tan(alpha * math.pi / 180) * (math.sin(beta * math.pi / 180) / math.cos(gamma * math.pi / 180))) - 
        (math.tan(gamma * math.pi / 180) * math.cos(beta * math.pi / 180)))

        Tg = P_kg * ((math.tan(alpha * math.pi / 180) * (math.sin(beta * math.pi / 180) / math.cos(gamma * math.pi / 180))) + 
        (math.tan(gamma * math.pi / 180) * math.cos(beta * math.pi / 180)))

        r1 = pinion_dia/2
        r2 = (r1 * (NP/NG))*10

        a = a/1000
        b = b/1000
        c = c/1000
        d = d/1000

        PCD_pinion_1 = (NP*M)/(math.cos(helix*math.pi/180))
        PCD_pinion_2 = (NG*M)/(math.cos(helix*math.pi/180))

        N_ip = N/(NG/NP)

        ip_torq_kgm = (4500*HP)/(2*math.pi*N_ip)
        
        Tang_force_P = ((ip_torq_kgm*2000)/(PCD_pinion_1))
        P = Tang_force_P*0.009807
        Rad_load_S = (Tang_force_P*(math.tan(alpha*math.pi/180)))
        S = Rad_load_S*0.009807
        Axial_load_T = (Tang_force_P*(math.tan(helix*math.pi/180)))
        T = Axial_load_T*0.009807

        



        # Bearing Loads 
        #B1

        P1 = (P_kg) * (a/b)
        Tg1 = (Tp) * (a/b)
        Tp1 = (Tg) * (r1/b)
        rad_load_B1 = (math.sqrt((Tg1-Tp1)**2 + (P1)**2))*0.009807 
        rad_B1_KN = rad_load_B1 * 0.009807

        #B2

        P2 = P_kg * ((a+b)/b)
        Tg2 = Tp * ((a+b)/b)
        Tp2 = Tp1
        rad_load_B2 = (math.sqrt((Tg2-Tp2)**2 + (P2)**2))*0.009807
        rad_B2_KN = rad_load_B2 * 0.009807

        #B3

        P3 = P_kg * ((d)/(c+d))
        Tg3 = Tp * ((r2)/(c+d))
        Tp3 = Tg * ((d)/(c+d))
        rad_load_B3 = (math.sqrt((P3)**2 + (Tg3+Tp3)**2 ))* 0.009807
        rad_B3_KN = rad_load_B3 * 0.009807



        #B4

        P4 = P_kg * (c/(c+d))
        Tg4 = Tg3
        Tp4 = Tg * (c/(c+d))
        rad_load_B4 = (math.sqrt((Tg4-Tp4)**2 + (P4)**2))* 0.009807
        rad_B4_KN = rad_load_B4 * 0.009807

        rad_loads = [rad_load_B1,rad_load_B2,rad_load_B3,rad_load_B4]

        rad_loads_KN = [rad_B1_KN,rad_B2_KN,rad_B3_KN,rad_B4_KN]


        #New bearing loads

        #Bearing_1
        BP1 = P*((a1)/(a1+b1))
        BS1 = S * ((a1)/(a1+b1))
        BT1 = T * ((PCD_pinion_1/2)/(a1+b1))

        B1_rad_load = (math.sqrt((BP1)**2 + (BS1-BT1)**2 ))

        #Bearing_2
        BP2 = P*((b1)/(a1+b1))
        BS2 = S * ((b1)/(a1+b1))
        BT2 = T * ((PCD_pinion_1/2)/(a1+b1))

        B2_rad_load = (math.sqrt((BP2)**2 + (BS2-BT2)**2 ))
        
        #Bearing_3
        BP3 = P*((c1)/(c1+d1))
        BS3 = S * ((c1)/(c1+d1))
        BT3 = T * ((PCD_pinion_2/2)/(c1+d1))
        
        B3_rad_load = (math.sqrt((BP3)**2 + (BS3-BT3)**2 ))

        #Bearing_4
        BP4 = P*((d1)/(c1+d1))
        BS4 = S * ((d1)/(c1+d1))
        BT4 = T * ((PCD_pinion_2/2)/(c1+d1))
        
        B4_rad_load = (math.sqrt((BP4)**2 + (BS4-BT4)**2 ))

        B_rad_loads = [B1_rad_load,B2_rad_load,B3_rad_load,B4_rad_load]

        #Bevel_Pinion
        Bevel_pinion_B1 = rad_load_B1 
        Bearing_B2 = rad_load_B2
        Bevel_trust_B1 = Tg * 0.009807
        Bevel_pin_RPM = N

        #Stage1_Bevel_Helical 
        stage1_B1 =  rad_load_B3 + B1_rad_load
        stage1_B2 = B2_rad_load + rad_load_B4
        stage1_rpm = N_ip
        stage1_T = T+(-Tp*0.009807)



        return render_template('index.html', rad_loads=rad_loads,rad_loads_KN=rad_loads_KN,B_rad_loads=B_rad_loads,P_kg=P_kg,beta=beta,Tp=Tp,Tg=Tg,Q_kg_m=Q_kg_m,r1=r1,r2=r2,
        P=P ,S=S ,T=T,PCD1=PCD_pinion_1,PCD2=PCD_pinion_2, BP_B1 = Bevel_pinion_B1, BP_B2 = Bearing_B2, BP_T = Bevel_trust_B1, BP_RPM = Bevel_pin_RPM,
        S1_B1 = stage1_B1, S1_B2 = stage1_B2, S1_RPM = stage1_rpm, S1_T = stage1_T )

    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)










